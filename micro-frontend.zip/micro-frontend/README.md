# マイクロサービス フロントエンド

Material Design 3を採用したReactベースのマイクロサービス管理フロントエンドアプリケーションです。

## 🚀 特徴

- **Material Design 3**: Googleの最新デザインシステムを採用
- **React + TypeScript**: 型安全性を重視したモダンな開発環境
- **レスポンシブデザイン**: デスクトップ・タブレット・モバイル対応
- **マイクロサービス管理**: サービスの監視、制御、設定管理
- **リアルタイム監視**: ダッシュボードでのシステム状況表示

## 🛠️ 技術スタック

### フロントエンド
- **React 18** - UIライブラリ
- **TypeScript** - 型安全性
- **Vite** - 高速ビルドツール
- **Material UI v6** - Material Design 3対応UIコンポーネント
- **React Router v6** - ルーティング
- **Emotion** - CSS-in-JS

### デザインシステム
- **Material Design 3** - Google公式デザインシステム
- **Roboto フォント** - Material Design標準フォント
- **Material Icons** - 一貫性のあるアイコンセット

## 📦 インストール

### 前提条件
- Node.js 18.0.0 以上
- npm または yarn

### セットアップ手順

1. **リポジトリのクローン**
```bash
git clone <repository-url>
cd micro-frontend
```

2. **依存関係のインストール**
```bash
npm install
```

3. **開発サーバーの起動**
```bash
npm run dev
```

4. **ブラウザでアクセス**
```
http://localhost:5173
```

## 📂 プロジェクト構造

```
src/
├── components/          # 再利用可能なコンポーネント
│   ├── Common/         # 共通コンポーネント
│   │   ├── ServiceCard.tsx
│   │   └── StatsCard.tsx
│   └── Layout/         # レイアウトコンポーネント
│       └── AppLayout.tsx
├── pages/              # ページコンポーネント
│   ├── Dashboard.tsx   # ダッシュボード
│   ├── Analytics.tsx   # アナリティクス
│   ├── Profile.tsx     # プロフィール
│   ├── Notifications.tsx # 通知
│   └── Settings.tsx    # 設定
├── router/             # ルーティング設定
│   └── AppRouter.tsx
├── theme/              # テーマ設定
│   ├── materialTheme.ts
│   └── mui.d.ts
├── App.tsx             # メインアプリケーション
└── main.tsx            # エントリーポイント
```

## 🎨 カラーパレット

Material Design 3の公式カラーシステムを採用：

- **Primary**: `#6750A4` - メインブランドカラー
- **Secondary**: `#625B71` - セカンダリーアクセント
- **Tertiary**: `#7D5260` - サードアクセント
- **Surface**: `#FFFBFE` - 背景色
- **Error**: `#BA1A1A` - エラー表示

## 📱 ページ概要

### 1. ダッシュボード (`/`)
- システム全体のステータス表示
- アクティブサービス数、レスポンス時間、リソース使用量
- サービス一覧とステータス管理
- サービスの開始・停止・設定

### 2. アナリティクス (`/analytics`)
- システムパフォーマンス分析
- ユーザー行動データ
- トラフィック推移とデバイス別統計
- 人気ページランキング

### 3. プロフィール (`/profile`)
- ユーザー情報の表示・編集
- アカウント設定
- セキュリティ設定

### 4. 通知 (`/notifications`)
- システム通知の管理
- アラートとメッセージ
- 既読・未読フィルタリング

### 5. 設定 (`/settings`)
- アプリケーション設定
- テーマとローカライゼーション
- パフォーマンス設定
- システム情報

## 🔧 開発スクリプト

```bash
# 開発サーバー起動
npm run dev

# プロダクションビルド
npm run build

# ビルド結果のプレビュー
npm run preview

# 型チェック
npm run type-check

# Linting
npm run lint
```

## 🎯 今後の拡張予定

- [ ] ダークテーマサポート
- [ ] 多言語対応の強化
- [ ] リアルタイムチャート表示
- [ ] WebSocket接続によるリアルタイム更新
- [ ] PWA対応
- [ ] テストケースの追加

## 🤝 コントリビューション

1. フォークしてください
2. フィーチャーブランチを作成してください (`git checkout -b feature/AmazingFeature`)
3. 変更をコミットしてください (`git commit -m 'Add some AmazingFeature'`)
4. ブランチにプッシュしてください (`git push origin feature/AmazingFeature`)
5. プルリクエストを開いてください

## 📄 ライセンス

このプロジェクトはMITライセンスのもとで公開されています。

## 📞 サポート

問題や質問がある場合は、以下の方法でお気軽にお問い合わせください：

- GitHub Issues
- 開発チームへの直接連絡

---

**Material Design 3 × React で構築された、次世代のマイクロサービス管理プラットフォーム**

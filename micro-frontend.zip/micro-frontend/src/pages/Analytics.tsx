import React from 'react';
import {
  Container,
  Typography,
  Grid,
  Box,
  Paper,
  LinearProgress,
} from '@mui/material';
import {
  TrendingUp,
  Visibility,
  Group,
  Speed,
} from '@mui/icons-material';
import StatsCard from '../components/Common/StatsCard';

const Analytics: React.FC = () => {
  return (
    <Container maxWidth="xl">
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" sx={{ mb: 1, fontWeight: 600 }}>
          アナリティクス
        </Typography>
        <Typography variant="body1" color="text.secondary">
          システムパフォーマンスとユーザー行動の分析データ
        </Typography>
      </Box>

      {/* メトリクスカード */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="月間アクティブユーザー"
            value="24,532"
            subtitle="MAU"
            trend="up"
            trendValue="+12.5%"
            icon={Group}
            color="primary"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="ページビュー"
            value="1.2M"
            subtitle="今月"
            trend="up"
            trendValue="+8.2%"
            icon={Visibility}
            color="success"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="コンバージョン率"
            value="3.42%"
            subtitle="CV率"
            trend="up"
            trendValue="+0.3%"
            icon={TrendingUp}
            color="warning"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="平均セッション時間"
            value="4m 32s"
            subtitle="滞在時間"
            trend="down"
            trendValue="-0.8%"
            icon={Speed}
            color="secondary"
          />
        </Grid>
      </Grid>

      {/* チャートエリア */}
      <Grid container spacing={3}>
        <Grid item xs={12} lg={8}>
          <Paper sx={{ p: 3, borderRadius: 3 }}>
            <Typography variant="h6" sx={{ mb: 3, fontWeight: 600 }}>
              トラフィック推移
            </Typography>
            <Box sx={{ height: 300, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Typography color="text.secondary">
                ここにトラフィックチャートが表示されます
              </Typography>
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={12} lg={4}>
          <Paper sx={{ p: 3, borderRadius: 3, mb: 3 }}>
            <Typography variant="h6" sx={{ mb: 3, fontWeight: 600 }}>
              デバイス別アクセス
            </Typography>
            <Box sx={{ mb: 2 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2">デスクトップ</Typography>
                <Typography variant="body2">65%</Typography>
              </Box>
              <LinearProgress variant="determinate" value={65} />
            </Box>
            <Box sx={{ mb: 2 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2">モバイル</Typography>
                <Typography variant="body2">28%</Typography>
              </Box>
              <LinearProgress variant="determinate" value={28} />
            </Box>
            <Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2">タブレット</Typography>
                <Typography variant="body2">7%</Typography>
              </Box>
              <LinearProgress variant="determinate" value={7} />
            </Box>
          </Paper>
          <Paper sx={{ p: 3, borderRadius: 3 }}>
            <Typography variant="h6" sx={{ mb: 3, fontWeight: 600 }}>
              人気ページ
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="body2">/dashboard</Typography>
                <Typography variant="body2" color="primary">32.5%</Typography>
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="body2">/analytics</Typography>
                <Typography variant="body2" color="primary">18.2%</Typography>
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="body2">/profile</Typography>
                <Typography variant="body2" color="primary">15.8%</Typography>
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="body2">/settings</Typography>
                <Typography variant="body2" color="primary">12.1%</Typography>
              </Box>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Analytics; 
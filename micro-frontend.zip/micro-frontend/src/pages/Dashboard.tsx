import React from 'react';
import {
  Container,
  Typography,
  Grid,
  Box,
  Button,
  Fab,
} from '@mui/material';
import {
  Add as AddIcon,
  CloudQueue as CloudIcon,
  Speed as SpeedIcon,
  Memory as MemoryIcon,
  Storage as StorageIcon,
} from '@mui/icons-material';
import StatsCard from '../components/Common/StatsCard';
import ServiceCard from '../components/Common/ServiceCard';

const Dashboard: React.FC = () => {
  const handleServiceAction = (action: string, serviceName: string) => {
    console.log(`${action} action for ${serviceName}`);
    // Here you would typically call your microservice API
  };

  return (
    <Container maxWidth="xl">
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" sx={{ mb: 1, fontWeight: 600 }}>
          マイクロサービス ダッシュボード
        </Typography>
        <Typography variant="body1" color="text.secondary">
          システム全体の状況とサービスの管理を行います
        </Typography>
      </Box>

      {/* 統計カード */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="アクティブサービス"
            value={8}
            subtitle="実行中のサービス"
            trend="up"
            trendValue="+2"
            icon={CloudIcon}
            color="success"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="平均レスポンス時間"
            value="125ms"
            subtitle="API応答時間"
            trend="down"
            trendValue="-15ms"
            icon={SpeedIcon}
            color="primary"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="メモリ使用量"
            value="68%"
            subtitle="システム全体"
            trend="up"
            trendValue="+5%"
            icon={MemoryIcon}
            color="warning"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="ストレージ"
            value="2.3TB"
            subtitle="総使用量"
            trend="neutral"
            trendValue="0%"
            icon={StorageIcon}
            color="secondary"
          />
        </Grid>
      </Grid>

      {/* サービス一覧 */}
      <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h5" component="h2" sx={{ fontWeight: 600 }}>
          サービス一覧
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          sx={{ borderRadius: 3 }}
        >
          新しいサービス
        </Button>
      </Box>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6} lg={4}>
          <ServiceCard
            title="ユーザー認証サービス"
            description="JWT認証とユーザー管理を担当するマイクロサービス。セキュリティとセッション管理を提供。"
            status="running"
            version="2.1.3"
            lastUpdated="2024年1月15日"
            onStart={() => handleServiceAction('start', 'auth-service')}
            onStop={() => handleServiceAction('stop', 'auth-service')}
            onConfigure={() => handleServiceAction('configure', 'auth-service')}
          />
        </Grid>
        <Grid item xs={12} md={6} lg={4}>
          <ServiceCard
            title="決済処理サービス"
            description="オンライン決済と請求処理を管理。Stripe APIとの統合。"
            status="running"
            version="1.8.7"
            lastUpdated="2024年1月14日"
            onStart={() => handleServiceAction('start', 'payment-service')}
            onStop={() => handleServiceAction('stop', 'payment-service')}
            onConfigure={() => handleServiceAction('configure', 'payment-service')}
          />
        </Grid>
        <Grid item xs={12} md={6} lg={4}>
          <ServiceCard
            title="通知サービス"
            description="メール、SMS、プッシュ通知の配信を担当。マルチチャンネル対応。"
            status="pending"
            version="1.4.2"
            lastUpdated="2024年1月13日"
            onStart={() => handleServiceAction('start', 'notification-service')}
            onStop={() => handleServiceAction('stop', 'notification-service')}
            onConfigure={() => handleServiceAction('configure', 'notification-service')}
          />
        </Grid>
        <Grid item xs={12} md={6} lg={4}>
          <ServiceCard
            title="ファイル管理サービス"
            description="ファイルアップロード、ストレージ、CDN配信を管理。"
            status="stopped"
            version="3.0.1"
            lastUpdated="2024年1月12日"
            onStart={() => handleServiceAction('start', 'file-service')}
            onStop={() => handleServiceAction('stop', 'file-service')}
            onConfigure={() => handleServiceAction('configure', 'file-service')}
          />
        </Grid>
        <Grid item xs={12} md={6} lg={4}>
          <ServiceCard
            title="データ分析サービス"
            description="ユーザー行動分析とレポート生成。機械学習モデルの推論。"
            status="running"
            version="2.3.0"
            lastUpdated="2024年1月11日"
            onStart={() => handleServiceAction('start', 'analytics-service')}
            onStop={() => handleServiceAction('stop', 'analytics-service')}
            onConfigure={() => handleServiceAction('configure', 'analytics-service')}
          />
        </Grid>
        <Grid item xs={12} md={6} lg={4}>
          <ServiceCard
            title="検索サービス"
            description="Elasticsearchベースの高速検索機能を提供。"
            status="running"
            version="1.9.4"
            lastUpdated="2024年1月10日"
            onStart={() => handleServiceAction('start', 'search-service')}
            onStop={() => handleServiceAction('stop', 'search-service')}
            onConfigure={() => handleServiceAction('configure', 'search-service')}
          />
        </Grid>
      </Grid>

      {/* フローティングアクションボタン */}
      <Fab
        color="primary"
        aria-label="add"
        sx={{
          position: 'fixed',
          bottom: 24,
          right: 24,
        }}
      >
        <AddIcon />
      </Fab>
    </Container>
  );
};

export default Dashboard; 
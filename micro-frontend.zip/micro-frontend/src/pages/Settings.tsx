import React, { useState } from 'react';
import {
  Container,
  Typography,
  Grid,
  Box,
  Paper,
  Switch,
  FormControlLabel,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Button,
  Divider,
  Slider,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from '@mui/material';
import {
  ExpandMore,
  Security,
  Notifications,
  Language,
  Palette,
  Storage,
  Api,
} from '@mui/icons-material';

const Settings: React.FC = () => {
  const [settings, setSettings] = useState({
    theme: 'light',
    language: 'ja',
    notifications: {
      email: true,
      push: true,
      sms: false,
    },
    security: {
      twoFactor: true,
      sessionTimeout: 30,
    },
    performance: {
      autoRefresh: true,
      refreshInterval: 30,
      maxConcurrentRequests: 10,
    },
  });

  const handleSettingChange = (category: string, key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category as keyof typeof prev],
        [key]: value,
      },
    }));
  };

  const handleSingleSettingChange = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <Container maxWidth="md">
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" sx={{ mb: 1, fontWeight: 600 }}>
          設定
        </Typography>
        <Typography variant="body1" color="text.secondary">
          システム設定とユーザー設定の管理
        </Typography>
      </Box>

      <Grid container spacing={3}>
        {/* 外観設定 */}
        <Grid item xs={12}>
          <Accordion defaultExpanded>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Palette color="primary" />
                <Typography variant="h6">外観設定</Typography>
              </Box>
            </AccordionSummary>
            <AccordionDetails>
              <Grid container spacing={3}>
                <Grid item xs={12} sm={6}>
                  <FormControl fullWidth>
                    <InputLabel>テーマ</InputLabel>
                    <Select
                      value={settings.theme}
                      onChange={(e) => handleSingleSettingChange('theme', e.target.value)}
                      label="テーマ"
                    >
                      <MenuItem value="light">ライト</MenuItem>
                      <MenuItem value="dark">ダーク</MenuItem>
                      <MenuItem value="auto">自動</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControl fullWidth>
                    <InputLabel>言語</InputLabel>
                    <Select
                      value={settings.language}
                      onChange={(e) => handleSingleSettingChange('language', e.target.value)}
                      label="言語"
                    >
                      <MenuItem value="ja">日本語</MenuItem>
                      <MenuItem value="en">English</MenuItem>
                      <MenuItem value="ko">한국어</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
              </Grid>
            </AccordionDetails>
          </Accordion>
        </Grid>

        {/* 通知設定 */}
        <Grid item xs={12}>
          <Accordion>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Notifications color="primary" />
                <Typography variant="h6">通知設定</Typography>
              </Box>
            </AccordionSummary>
            <AccordionDetails>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={settings.notifications.email}
                      onChange={(e) => handleSettingChange('notifications', 'email', e.target.checked)}
                    />
                  }
                  label="メール通知"
                />
                <FormControlLabel
                  control={
                    <Switch
                      checked={settings.notifications.push}
                      onChange={(e) => handleSettingChange('notifications', 'push', e.target.checked)}
                    />
                  }
                  label="プッシュ通知"
                />
                <FormControlLabel
                  control={
                    <Switch
                      checked={settings.notifications.sms}
                      onChange={(e) => handleSettingChange('notifications', 'sms', e.target.checked)}
                    />
                  }
                  label="SMS通知"
                />
              </Box>
            </AccordionDetails>
          </Accordion>
        </Grid>

        {/* セキュリティ設定 */}
        <Grid item xs={12}>
          <Accordion>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Security color="primary" />
                <Typography variant="h6">セキュリティ設定</Typography>
              </Box>
            </AccordionSummary>
            <AccordionDetails>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={settings.security.twoFactor}
                      onChange={(e) => handleSettingChange('security', 'twoFactor', e.target.checked)}
                    />
                  }
                  label="二段階認証"
                />
                <Box>
                  <Typography gutterBottom>
                    セッションタイムアウト: {settings.security.sessionTimeout}分
                  </Typography>
                  <Slider
                    value={settings.security.sessionTimeout}
                    onChange={(e, value) => handleSettingChange('security', 'sessionTimeout', value)}
                    min={5}
                    max={120}
                    step={5}
                    marks
                    valueLabelDisplay="auto"
                  />
                </Box>
              </Box>
            </AccordionDetails>
          </Accordion>
        </Grid>

        {/* パフォーマンス設定 */}
        <Grid item xs={12}>
          <Accordion>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Api color="primary" />
                <Typography variant="h6">パフォーマンス設定</Typography>
              </Box>
            </AccordionSummary>
            <AccordionDetails>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={settings.performance.autoRefresh}
                      onChange={(e) => handleSettingChange('performance', 'autoRefresh', e.target.checked)}
                    />
                  }
                  label="自動更新"
                />
                <Box>
                  <Typography gutterBottom>
                    更新間隔: {settings.performance.refreshInterval}秒
                  </Typography>
                  <Slider
                    value={settings.performance.refreshInterval}
                    onChange={(e, value) => handleSettingChange('performance', 'refreshInterval', value)}
                    disabled={!settings.performance.autoRefresh}
                    min={10}
                    max={300}
                    step={10}
                    marks
                    valueLabelDisplay="auto"
                  />
                </Box>
                <Box>
                  <Typography gutterBottom>
                    最大同時リクエスト数: {settings.performance.maxConcurrentRequests}
                  </Typography>
                  <Slider
                    value={settings.performance.maxConcurrentRequests}
                    onChange={(e, value) => handleSettingChange('performance', 'maxConcurrentRequests', value)}
                    min={1}
                    max={50}
                    step={1}
                    marks
                    valueLabelDisplay="auto"
                  />
                </Box>
              </Box>
            </AccordionDetails>
          </Accordion>
        </Grid>

        {/* システム情報 */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3, borderRadius: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
              <Storage color="primary" />
              <Typography variant="h6">システム情報</Typography>
            </Box>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <Typography variant="body2" color="text.secondary">
                  アプリケーションバージョン
                </Typography>
                <Typography variant="body1">v2.1.0</Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="body2" color="text.secondary">
                  ビルド日時
                </Typography>
                <Typography variant="body1">2024年1月15日 14:30</Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="body2" color="text.secondary">
                  環境
                </Typography>
                <Typography variant="body1">Production</Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="body2" color="text.secondary">
                  API バージョン
                </Typography>
                <Typography variant="body1">v3.2.1</Typography>
              </Grid>
            </Grid>
          </Paper>
        </Grid>

        {/* アクションボタン */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3, borderRadius: 3 }}>
            <Box sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
              <Button variant="outlined" sx={{ borderRadius: 3 }}>
                リセット
              </Button>
              <Button variant="contained" sx={{ borderRadius: 3 }}>
                設定を保存
              </Button>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Settings; 
import React from 'react';
import {
  Card,
  CardContent,
  CardActions,
  Typography,
  Button,
  Chip,
  Box,
  useTheme,
} from '@mui/material';
import { PlayArrow, Stop, Settings } from '@mui/icons-material';

interface ServiceCardProps {
  title: string;
  description: string;
  status: 'running' | 'stopped' | 'pending';
  version: string;
  lastUpdated: string;
  onStart?: () => void;
  onStop?: () => void;
  onConfigure?: () => void;
}

const ServiceCard: React.FC<ServiceCardProps> = ({
  title,
  description,
  status,
  version,
  lastUpdated,
  onStart,
  onStop,
  onConfigure,
}) => {
  const theme = useTheme();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running':
        return theme.palette.success.main;
      case 'stopped':
        return theme.palette.error.main;
      case 'pending':
        return theme.palette.warning.main;
      default:
        return theme.palette.grey[500];
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'running':
        return '実行中';
      case 'stopped':
        return '停止中';
      case 'pending':
        return '待機中';
      default:
        return '不明';
    }
  };

  return (
    <Card
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        transition: 'all 0.2s ease-in-out',
        '&:hover': {
          transform: 'translateY(-2px)',
        },
      }}
    >
      <CardContent sx={{ flexGrow: 1 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
          <Typography variant="h6" component="h2" sx={{ fontWeight: 600 }}>
            {title}
          </Typography>
          <Chip
            label={getStatusText(status)}
            size="small"
            sx={{
              backgroundColor: getStatusColor(status),
              color: 'white',
              fontWeight: 500,
            }}
          />
        </Box>
        
        <Typography
          variant="body2"
          color="text.secondary"
          sx={{ mb: 2, lineHeight: 1.6 }}
        >
          {description}
        </Typography>

        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
          <Chip
            label={`v${version}`}
            variant="outlined"
            size="small"
            sx={{ backgroundColor: theme.palette.primary.light }}
          />
          <Typography variant="caption" color="text.secondary" sx={{ alignSelf: 'center' }}>
            最終更新: {lastUpdated}
          </Typography>
        </Box>
      </CardContent>

      <CardActions sx={{ p: 2, pt: 0 }}>
        <Box sx={{ display: 'flex', gap: 1, width: '100%' }}>
          {status === 'stopped' ? (
            <Button
              size="small"
              variant="contained"
              startIcon={<PlayArrow />}
              onClick={onStart}
              sx={{ flex: 1 }}
            >
              開始
            </Button>
          ) : (
            <Button
              size="small"
              variant="outlined"
              startIcon={<Stop />}
              onClick={onStop}
              sx={{ flex: 1 }}
            >
              停止
            </Button>
          )}
          <Button
            size="small"
            variant="text"
            startIcon={<Settings />}
            onClick={onConfigure}
          >
            設定
          </Button>
        </Box>
      </CardActions>
    </Card>
  );
};

export default ServiceCard; 